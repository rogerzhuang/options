TICKER_MAPPING = {
    'BRK.B': 'BRK-B',
}

# Database configurations
DB_SERVER = 'sql01.qedgeam.com\\sql_trader'
DB_USER = 'leroy'
DB_PASSWORD = 'Leroy123'
DB_NAME = 'Polygon'

# Polygon API key
POLYGON_API_KEY = 'aA9VC_s244ilFsb8S0KOgoHza_5vzMXl'
